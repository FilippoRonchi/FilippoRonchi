/*file js per il posizionamento delle funzioni globali*/

function logOut() {
    alert("Ti sei disconnesso!\n" +
        "non è vero!");
}