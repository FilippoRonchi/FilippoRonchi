<?php
function visualizza($variabile){
?>  
<?php require __DIR__ . '/parcials/header.php'; ?>
<body>
    <h1>Bella Fra</h1>
    <?php echo $variabile ?>

</body>
</html> 
<?php  }?>



